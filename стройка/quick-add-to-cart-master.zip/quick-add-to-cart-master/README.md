Quick Add To Cart
=========

A handy snippet to let users customize a product directly from the products gallery, and add it to the cart.

[Article on CodyHouse](http://codyhouse.co/gem/quick-add-to-cart/)

[Demo](http://codyhouse.co/demo/quick-add-to-cart/index.html)

Icons by [Nucleo](https://nucleoapp.com/)
 
[Terms](http://codyhouse.co/terms/)
