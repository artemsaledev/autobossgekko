<?php
define('INCLUDE_CHECK',1);
require "../connect.php";

if(!$_POST['img']) die("Нет таких товаров!");

$img=mysql_real_escape_string(end(explode('/',$_POST['img'])));

$row=mysql_fetch_assoc(mysql_query("SELECT * FROM internet_shop WHERE img='".$img."'"));

if(!$row) die("Нет таких товаров!");

echo '<strong>'.$row['name'].'</strong>
<p class="descr">'.$row['description'].'</p>
<strong>price: $'.$row['price'].'</strong>
<small>Для того, чтобы купить, просто перетащите его в коризну</small>';

 ;?>